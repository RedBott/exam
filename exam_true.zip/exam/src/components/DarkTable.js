import React from "react"
import MUIDataTable from "mui-datatables";
import { createMuiTheme, MuiThemeProvider} from '@material-ui/core/styles';


class DarkTable extends React.Component {
    constructor(props) {
        super(props);
        this.tableRef = React.createRef();
    }
    state = {
        stats: [],
        loading: false
    }

    getMuiTheme = () => createMuiTheme({
        overrides: {
            MUIDataTable: {
                root: {
                  backgroundColor: "inherit",
                 
                },
                paper: {
                  boxShadow: "none"
                }
              },
          MUIDataTableBodyCell: {
            root: {
              backgroundColor: "none",
              
            }
          }
        }
      })

      componentDidMount() {
             this.setState({ loading: true })
             fetch('https://sv443.net/jokeapi/v2/joke/Dark?type=single')
                 .then(response => response.json())
                 .then(res => {
                     this.setState({ stats: res, loading: false })
                 })
                 .catch(error => {
                 })
         }

    
render(){
    return(
        <React.Fragment>
          <div style={{marginLeft:'10px',marginRight:'10px'}}>   
           <br/>
            
              <MuiThemeProvider theme={this.getMuiTheme()}>
                <MUIDataTable 
                    title={<h1 style={{float:'left',color: '#3f51b5',}}>Jokes About Programming</h1>}
                    isLoading={this.state.loading}
                    columns ={[
                      {
                          name: "category",
                          label: "Category",
                          options: {
                          filter: true,
                          sort: true
                          }
                      },
                      {
                          name: "type",
                          label: "Type",
                          options: {
                          filter: true,
                          sort: true
                          }
                      },
                      {
                        name: "joke",
                        label: "Joke",
                        options: {
                        filter: false,
                        sort: false
                        }
                    }
        
            
                  ]} 
                    
                    data = {this.state.stats}
                    
                    options = {{ 
                      filter: true,
                      rowHover:true,
                      downloadOptions:{filename: 'DarkTable.csv', separator: ','},
                      selectableRows: false,
                      printButton: false,
                      rowsPerPage: 10,
                      print: false,
                      responsive: 'stacked',}}/>
               </MuiThemeProvider>
         </div>
      </React.Fragment>
    )
  }
}

export default DarkTable;