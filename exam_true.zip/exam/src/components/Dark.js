import React from 'react';
import {
  Card, CardImg, CardText, CardBody,
  CardTitle, CardSubtitle, Button
} from 'reactstrap';
import { BrowserRouter as Router, Switch, Route, Link} from "react-router-dom";
import Login from '../Login';

const Dark = (props) => {
  return (
    <Router>
    <div>
      <Card>
        <CardBody>
          <CardTitle>Dark</CardTitle>
          <CardText>Dark Jokes</CardText>
          <Button><Link to={'/Login'}>Go To</Link></Button>
        </CardBody>
      </Card>
    </div>
    <hr/>
    <Switch>
    <Route path='/Login' component={Login}/>
  </Switch>
    </Router>
  );
};

export default Dark;